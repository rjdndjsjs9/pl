<?php
namespace IPTools\Exception;

use Exception;

final class RangeException extends Exception implements IpToolsException
{
}
