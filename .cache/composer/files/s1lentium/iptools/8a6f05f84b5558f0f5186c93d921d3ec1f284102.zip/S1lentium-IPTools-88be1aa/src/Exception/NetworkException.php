<?php
namespace IPTools\Exception;

use Exception;

final class NetworkException extends Exception implements IpToolsException
{
}
