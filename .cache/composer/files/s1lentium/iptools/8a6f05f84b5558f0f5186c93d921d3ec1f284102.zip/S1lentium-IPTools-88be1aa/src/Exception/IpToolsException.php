<?php
namespace IPTools\Exception;

interface IpToolsException
{
}
