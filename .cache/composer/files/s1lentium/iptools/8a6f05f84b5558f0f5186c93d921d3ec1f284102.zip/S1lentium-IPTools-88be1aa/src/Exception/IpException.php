<?php
namespace IPTools\Exception;

use Exception;

final class IpException extends Exception implements IpToolsException
{
}
