<?php

namespace Spatie\Fractalistic\Exceptions;

use Exception;

class InvalidTransformation extends Exception
{
}
