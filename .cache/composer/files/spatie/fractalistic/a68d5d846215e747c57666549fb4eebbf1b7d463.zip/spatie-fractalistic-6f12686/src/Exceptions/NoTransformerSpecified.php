<?php

namespace Spatie\Fractalistic\Exceptions;

use Exception;

class NoTransformerSpecified extends Exception
{
}
